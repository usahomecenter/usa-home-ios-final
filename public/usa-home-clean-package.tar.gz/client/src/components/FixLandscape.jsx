// This is the correct implementation with exact capitalization
else if (category === "Landscape Architect") {
  return [
    { value: "Site analysis & Master planning", label: "Site analysis & Master planning" },
    { value: "Planting Design", label: "Planting Design" },
    { value: "Hardscape Design", label: "Hardscape Design" },
    { value: "Irrigation & Drainage Systems", label: "Irrigation & Drainage Systems" },
    { value: "Sustainable Landscape Design", label: "Sustainable Landscape Design" }
  ];
}
